# -*- coding: utf-8 -*-

from ccxt.base.exchange import Exchange
from ccxt.abstract.satis import ImplicitAPI
import hashlib
from ccxt.base.types import OrderSide
from ccxt.base.types import OrderType
from typing import Optional
from typing import List
from ccxt.base.errors import ExchangeError
from ccxt.base.errors import PermissionDenied
from ccxt.base.errors import ArgumentsRequired
from ccxt.base.errors import BadRequest
from ccxt.base.errors import BadSymbol
from ccxt.base.errors import InsufficientFunds
from ccxt.base.errors import InvalidOrder
from ccxt.base.errors import OrderNotFound
from ccxt.base.errors import DDoSProtection
from ccxt.base.errors import ExchangeNotAvailable
from ccxt.base.errors import AuthenticationError
from ccxt.base.decimal_to_precision import TRUNCATE
from ccxt.base.decimal_to_precision import DECIMAL_PLACES
from ccxt.base.decimal_to_precision import TICK_SIZE
from ccxt.base.precise import Precise


class satis(Exchange, ImplicitAPI):

    def describe(self):
        return self.deep_extend(super(satis, self).describe(), {
            'id': 'satis',  # TODO
            'name': 'satis',  # TODO
            'countries': ['SC'],  # Seychelles # TODO
            'version': 'v1',  # TODO
            'userAgent': None,  # TODO
            # cheapest endpoints are 10 requests per second(trading)
            # 10 per second => rateLimit = 1000ms / 10 = 100ms
            # 120 per minute => 2 per second => weight = 5(authenticated)
            # 30 per minute => 0.5 per second => weight = 20(unauthenticated)
            'rateLimit': 3,  # TODO
            'pro': True,  # TODO
            'has': {
                'CORS': None,
                'spot': False,
                'margin': True,
                'swap': True,
                'future': False,
                'option': False,
                # 'addMargin': False,
                'cancelOrder': True,
                # 'cancelOrders': True,
                # 'createLimitBuyOrder': True,
                # 'createLimitSellOrder': True,
                # 'createMarketBuyOrder': True,
                # 'createMarketSellOrder': True,
                'createOrder': True,
                # 'createPostOnlyOrder': True,
                # 'createReduceOnlyOrder': False,
                # 'createStopLimitOrder': True,
                # 'createStopMarketOrder': False,
                # 'createStopOrder': True,
                'fetchAccounts': True,
                'fetchBalance': True,
                # 'fetchCanceledOrders': True,
                'fetchClosedOrders': True,
                'fetchCurrencies': True,
                # 'fetchFundingHistory': False,
                # 'fetchFundingRate': False,
                # 'fetchFundingRateHistory': False,
                # 'fetchFundingRates': False,
                # 'fetchIndexOHLCV': False,
                # 'fetchL2OrderBook': False,
                # 'fetchLedger': True,
                # 'fetchLeverage': False,
                'fetchMarkets': True,
                # 'fetchMarkOHLCV': False,
                # 'fetchMyBuys': True,
                # 'fetchMySells': True,
                # 'fetchMyTrades': True,
                'fetchOHLCV': True,
                # 'fetchOpenInterestHistory': False,
                # 'fetchOpenOrders': True,
                'fetchOrder': True,
                'fetchOrderBook': True,
                'fetchOrders': True,
                # 'fetchPosition': False,
                # 'fetchPositionMode': False,
                # 'fetchPositions': False,
                # 'fetchPositionsRisk': False,
                # 'fetchPremiumIndexOHLCV': False,
                'fetchTicker': True,
                'fetchTickers': False,  # TODO:
                'fetchTime': True,
                'fetchTrades': True,
                # 'fetchTradingFee': False,
                # 'reduceMargin': False,
                # 'setLeverage': False,
                # 'setMarginMode': False,
                # 'setPositionMode': False,
                # 'withdraw': None,
            },
            'timeframes': {
                '1m': 60,
                '5m': 300,
                '15m': 900,
                '1h': 3600,
                '6h': 21600,
                '1d': 86400,
            },
            'urls': {
                'logo': 'https://static.sat.is/logo/Satis_Logo_white.png',
                'api': 'http://3.145.182.17',  # TODO
                'doc': 'https://api-doc.sat.is',
            },
            'api': {
                'public': {
                    'get': [
                        'currencies',
                        'products',
                        'products/{product_id}/book',
                        'products/{product_id}/long_short_ratio',
                        'products/{product_id}/open_interest',
                        'products/{product_id}/ticker',
                        'products/{product_id}/trades',
                        'products/{product_id}/candles',
                        'products/{product_id}/stats',
                        'indices',
                        'time',
                    ],
                },
                'private': {
                    'get': [
                        'accounts',
                        'accounts/{account_id}',
                        'accounts/{account_id}/ledger',
                        'accounts/{account_id}/holds',
                        'fees',
                        'fills',
                        'orders',
                        'orders/{order_id}',
                        'positions/{product_id}',
                    ],
                    'post': [
                        'orders',
                        'positions/cross',
                        'positions/isolate',
                        'positions/margin',
                        'positions/risk',
                    ],
                    'delete': [
                        'orders',
                        'orders/{order_id}',
                    ],
                },
            },
            'fees': {  # TODO
                'trading': {
                    'percentage': True,
                    'maker': self.parse_number('0.0002'),
                    'taker': self.parse_number('0.0007'),
                },
                'precisionMode': DECIMAL_PLACES,  # TODO
            },
            'requiredCredentials': {
                'walletAddress': False,  # TODO: may remove later
                'privateKey': True,
                'apiKey': False,
                'secret': False,
            }, })

    def fetch_time(self, params={}):
        response = self.publicGetTime(params)
        # {
        #     "iso": "2023-06-27T10:13:23.069503+00:00",
        #     "epoch": "1687860803.69503"
        # }
        return self.safe_timestamp(response, 'epoch')

    def fetch_currencies(self, params={}):
        response = self.publicGetCurrencies(params)
        # [
        #     {
        #         "id": "btc",
        #         "min_size": "0.00000001",
        #         "name": "Bitcoin"
        #     },
        #     {
        #         "id": "eth",
        #         "min_size": "0.000000001",
        #         "name": "Ether"
        #     }
        # ]
        result = {}
        for i in range(0, len(response)):
            currency = response[i]
            id = self.safe_string(currency, 'id')
            name = self.safe_string(currency, 'name')
            min_size = self.safe_string(currency, 'min_size')
            code = self.safe_currency_code(id)
            result[code] = {
                'id': id,
                'code': code,
                'info': currency,
                'name': name,
                'active': True,
                'fee': None,
                'precision': self.precision_from_string(min_size),
                'withdraw': None,
                'deposit': None,
                'networks': None,
                'limits': {
                    'amount': {
                        'min': self.safe_number(currency, 'min_size'),
                        'max': None,
                    },
                    'withdraw': {
                        'min': None,
                        'max': None,
                    },
                },
            }
        return result

    def fetch_markets(self, params={}):
        response = self.publicGetProduct(params)
        # [{'id': 'btc_usdc',
        #   'display_name': 'btc-usdc',
        #   'base_currency': 'btc',
        #   'quote_currency': 'usdc',
        #   'quote_increment': '0.1',
        #   'base_min_size': '0.000001',
        #   'base_max_size': '10000000',
        #   'max_price': '1000000',
        #   'min_price': '0.1',
        #   'init_margin': '0.01',
        #   'maint_margin': '0.005',
        #   'risk_base_size': '20000000',
        #   'risk_step_size': '5000000',
        #   'status': 'online',
        #   'status_message': '',
        #   'trading_disabled': False,
        #   'multiplier': '-1',
        #   'is_inverse': False,
        #   'is_quanto': False,
        #   'settle_currency': 'usdc',
        #   'funding_rate': '0.000300',
        #   'next_funding_time': '2023-06-27T12:00:00.000000+00:00',
        #   'predicted_funding_rate': '0.0003',
        #   'can_cross': True,
        #   'risk_limits': []}]
        result = []
        for i in range(0, len(response)):
            market = response[i]
            id = self.safe_string(market, 'id')
            baseId = self.safe_string(market, 'base_currency')
            base = self.safe_currency_code(baseId)
            quoteId = self.safe_string(market, 'quote_currency')
            quote = self.safe_currency_code(quoteId)
            symbol = base + '/' + quote
            active = self.safe_string(market, 'status') == 'online'
            contractSize = self.safe_float(market, 'quote_increment')
            limits_price_min = self.safe_float(market, 'min_price')
            limits_price_max = self.safe_float(market, 'max_price')
            inverse = market['is_inverse']
            fees = self.safeValue(self.fees, 'trading')
            precision_amount = self.precision_from_string(self.safe_string(market, 'base_min_size'))
            precision_price = self.precision_from_string(self.safe_string(market, 'quote_increment'))
            max_amount = self.safe_float(market, 'base_max_size')
            min_amount = self.safe_float(market, 'base_min_size')

            result.append({
                'id': id,
                'symbol': symbol,
                'base': base,
                'quote': quote,
                'baseId': baseId,
                'quoteId': quoteId,
                'active': active,
                'type': 'swap',
                'spot': False,
                'margin': True,
                'future': False,
                'swap': True,
                'option': False,
                'contract': True,
                'settle': quote,
                'settleId': quoteId,
                'contractSize': contractSize,
                'linear': not inverse,
                'inverse': inverse,
                'expiry': None,
                'expiryDatetime': None,
                'strike': None,
                'optionType': None,
                'taker': self.safe_float(fees, 'taker'),
                'maker': self.safe_float(fees, 'maker'),
                'percentage': True,
                'tierBased': False,
                'feeSide': None,  # TODO check
                'precision': {
                    'amount': precision_amount,
                    'price': precision_price,
                },
                'limits': {
                    'amount': {
                        'min': min_amount,
                        'max': max_amount,
                    },
                    'price': {
                        'min': limits_price_min,
                        'max': limits_price_max,
                    },
                    'cost': {
                        'min': None,
                        'max': None,
                    },
                    'leverage': {
                        'min': None,
                        'max': None,
                    }
                },
                'info': market,
            })
        return result

    def fetch_accounts(self, params={}):
        self.load_markets()
        response = self.privateGetAccounts(params)
        return self.parse_accounts(response, params)

    def parse_account(self, account):
        currencyId = self.safe_string(account, 'currency')
        return {
            'id': self.safe_string(account, 'id'),
            'type': "swap",
            'code': self.safe_currency_code(currencyId),
            'name': None,
            'info': account,
        }

    def fetch_ticker(self, symbol: str, params={}):
        self.load_markets()
        market = self.market(symbol)
        request = {
            'product_id': market['id'],
        }
        response = self.publicGetTicker(self.extend(request, params))
        return self.parse_ticker(response, market)

    def parse_ticker(self, ticker, market=None):
        # {
        #     "best_ask": "41000",
        #     "best_bid": "40000",
        #     "high_24h": "37181.9",
        #     "last_size": 26,
        #     "low_24h": "29557.1",
        #     "mark_price": "33953.7373",
        #     "open_24h": "31304.9",
        #     "price": "31150.3",
        #     "product_id": "btc_usd",
        #     "side": "sell",
        #     "time": "2021-07-09T21:14:26.000849+00:00",
        #     "trade_id": 29765,
        #     "volume_24h": 17851
        # }

        timestamp = self.parse8601(self.safe_string(ticker, 'time'))
        marketId = self.safe_string(ticker, 'product_id')
        last = self.safe_float(ticker, 'last')
        return {
            'symbol': self.safe_symbol(marketId, market),
            'timestamp': timestamp,
            'datetime': self.iso8601(timestamp),
            'high': self.safe_float(ticker, 'high_24h'),
            'low': self.safe_float(ticker, 'low_24h'),
            'bid': self.safe_float(ticker, 'best_bid'),
            'bidVolume': None,
            'ask': self.safe_float(ticker, 'best_ask'),
            'askVolume': None,
            'vwap': None,
            'open': self.safe_float(ticker, 'open_24h'),
            'close': last,
            'last': last,
            'previousClose': None,
            'change': None,  # TODO
            'percentage': None,  # TODO
            'average': None,  # TODO
            'baseVolume': self.safe_float(ticker, 'volume_24h'),
            'quoteVolume': None,
            'info': ticker,
        }

    def fetch_order_book(self, symbol: str, limit: Optional[int] = None, params={}):
        """
        TODO: test limit
        """
        self.load_markets()
        market = self.market(symbol)
        request = {
            'product_id': market['id'],
            'level': 2,
        }
        response = self.publicGetOrderBook(
            self.extend(request, params))

        if limit and isinstance(limit, int):
            order_book = {}
            for side in ('bids', 'asks'):
                temp_book = self.safe_value(response, side, [])
                order_book[side] = temp_book[:limit]
        else:
            order_book = response
        return self.parse_order_book(order_book, symbol)

    # TODO: seems the base class has well implemented this method
    # def parse_order_book(self, orderbook, symbol, timestamp=None, bids_key='bids', asks_key='asks', price_key=0,
    #                      amount_key=1):
    #     return {
    #         'symbol': symbol,
    #         'bids': self.sort_by(self.parse_bids_asks(orderbook[bids_key], price_key, amount_key) if (
    #             bids_key in orderbook) and isinstance(
    #             orderbook[bids_key], list) else [], 0, True),
    #         'asks': self.sort_by(self.parse_bids_asks(orderbook[asks_key], price_key, amount_key) if (
    #             asks_key in orderbook) and isinstance(
    #             orderbook[asks_key], list) else [], 0),
    #         'timestamp': timestamp,
    #         'datetime': self.iso8601(timestamp) if timestamp is not None else None,
    #         'nonce': None,
    #     }

    def fetch_ohlcv(self, symbol: str, timeframe='1m', since: Optional[int] = None, limit: Optional[int] = None, params={}):
        self.load_markets()
        market = self.market(symbol)
        end = str(self.seconds())

        defaultLimit = 1500
        maxLimit = 1500
        limit = defaultLimit if (limit is None) else min(limit, maxLimit)
        request = {
            'product_id': market['id'],
            'granularity': self.safe_string(self.timeframes, timeframe, '60'),  # TODO: use default timeframe?
            'end': end,
        }
        duration = self.parse_timeframe(timeframe) * 1000
        if since is not None:
            sinceString = str(since)
            timeframeToSeconds = Precise.string_div(sinceString, '1000')
            request['start'] = self.decimal_to_precision(timeframeToSeconds, TRUNCATE, 0, DECIMAL_PLACES)
        else:
            request['start'] = Precise.string_sub(end, '18000')  # default to 5h in seconds, max 300 candles

        request['start'] = self.iso8601(int(request['start']) * 1000)
        request['end'] = self.iso8601(int(request['end']) * 1000)
        response = self.publicGetCandles(
            self.extend(request, params))
        # [
        #     [
        #         1625835780, # time
        #         31051.1,    # low
        #         32181.9,    # high
        #         31304.9,    # open
        #         31511.7,    # close
        #         981         # volume
        #     ],
        #     ...
        # ]
        return self.parse_ohlcvs(response, market, timeframe, since, limit)

    def fetch_trades(self, symbol: str, since: Optional[int] = None, limit: Optional[int] = None, params={}):
        self.load_markets()
        market = self.market(symbol)

        request = {
            'product_id': market['id'],
        }

        if limit is not None:
            request['limit'] = limit

        if since is not None:
            request['start'] = self.iso8601(since)

        trades = self.publicGetTrades(
            self.extend(request, params))
        # [
        #     {
        #         "price": "31150.3",
        #         "side": "sell",
        #         "size": 26,
        #         "time": "2021-07-09T21:14:26.000849+00:00",
        #         "trade_id": 29765
        #     },
        #     ...
        # ]
        return self.parse_trades(trades, None, since, limit, params={'symbol': symbol})
    
    def fetch_my_trades(self, symbol: Optional[str] = None, since: Optional[int] = None, limit: Optional[int] = None, params={}):
        self.load_markets()
        market = None
        if symbol is not None:
            market = self.market(symbol)
        request = {}
        if market is not None:
            request['product_id'] = market['id']
        if limit is not None:
            request['limit'] = limit
        if since is not None:
            request['start'] = self.iso8601(since)
        trades = self.privateGetFills(self.extend(request, params))
        return self.parse_trades(trades, market, since, limit)

    def parse_trade(self, trade, market=None):
        id = self.safe_string(trade, 'trade_id')

        marketId = self.safe_string(trade, 'product_id')
        symbol = self.safe_symbol(marketId, market)

        orderId = self.safe_string(trade, 'order_id')
        timestamp = self.parse8601(
            self.safe_string_2(trade, 'created_at', 'time'))

        amount = self.safe_float(trade, 'size')
        price = self.safe_float(trade, 'price')
        side = self.safe_string(trade, 'side')

        result = {
            'info': trade,
            'timestamp': timestamp,
            'datetime': self.iso8601(timestamp),
            'symbol': symbol,
            'id': id,
            'order': orderId,
            'type': None,
            'side': side,
            'price': price,
            'amount': amount,
        }

        liquidity = self.safe_string(trade, 'liquidity')
        if 'liquidity' in trade:
            if liquidity == 'T':
                takerOrMaker = 'taker'
            elif liquidity == 'M':
                takerOrMaker = 'maker'
            else:
                takerOrMaker = None
            result['takerOrMaker'] = takerOrMaker
        else:
            result['takerOrMaker'] = None

        if 'fee' in trade:
            # TODO
            pass
            # code = self.market(symbol)['base']
            # fee = None
            # feeCost = self.safe_number(trade, 'fee')
            # if feeCost is not None:
            #     feeCost = self.from_wei_by_code(feeCost, code)
            #     fee = {
            #         'cost': feeCost,
            #         'currency': code,
            #         'rate': None,
            #     }

            # cost = Precise.div(amount, price)
            # cost = Precise.string_abs(cost)
            # cost = self.currency_to_precision(code, cost)
            # cost = self.parse_number(cost)
            # result['fee'] = fee
            # result['cost'] = cost
        else:
            result['fee'] = None
            result['cost'] = None
        return result

    def fetch_balance(self, params={}):
        self.load_markets()
        response = self.privateGetAccounts(params)
        return self.parse_balance(response)

    def parse_balance(self, response):
        result = {'info': response}
        for i in range(0, len(response)):
            balance = response[i]
            currencyId = self.safe_string(balance, 'currency')
            code = self.safe_currency_code(currencyId)
            account = self.account()
            free = self.safe_number(balance, 'free')
            total = self.safe_number(balance, 'balance')
            account['free'] = free
            account['total'] = total
            result[code] = account
        return self.safe_balance(result)

    def fetch_order(self, id: str, symbol: Optional[str] = None, params={}):                
        request = {
            'order_id': id,
        }
        response = self.privateGetOrder(self.extend(request, params))
        return self.parse_order(response)
    
    def fetch_orders(self, symbol: Optional[str] = None, since: Optional[int] = None, limit=100, params={}):
        self.load_markets()
        market = None
        if symbol is not None:
            market = self.market(symbol)
        request = {}
        if market is not None:
            request['product_id'] = market['id']
        if limit is not None:
            request['limit'] = limit
        if since is not None:
            request['start'] = self.iso8601(since)
        response = self.privateGetOrders(self.extend(request, params))
        return self.parse_orders(response, market, since, limit)
    
    def fetch_orders_by_status(self, status, symbol: Optional[str] = None, since: Optional[int] = None, limit: Optional[int] = None, params={}):
        self.load_markets()
        market = None
        if symbol is not None:
            market = self.market(symbol)
        request = {
            'status': status,
        }
        if market is not None:
            request['product_id'] = market['id']
        if limit is not None:
            request['limit'] = limit
        if since is not None:
            request['start'] = self.iso8601(since)
        response = self.privateGetOrders(self.extend(request, params))
        return self.parse_orders(response, market, since, limit)

    def fetch_open_orders(self, symbol: Optional[str] = None, since: Optional[int] = None, limit: Optional[int] = None, params={}):
        return self.fetch_orders_by_status('open', symbol, since, limit, params)

    def fetch_closed_orders(self, symbol: Optional[str] = None, since: Optional[int] = None, limit: Optional[int] = None, params={}):
        return self.fetch_orders_by_status('done', symbol, since, limit, params)

    def parse_order_status(self, status, reason=None):
        if not reason:
            done_status = 'closed'
        elif reason == 'Canceled':
            done_status = 'canceled'
        else:
            done_status = 'rejected'

        statuses = {
            'pending': 'open',
            'received': 'open',
            'open': 'open',
            'done': done_status,  
        }
        return self.safe_string(statuses, status, status)

    def parse_order(self, order, market=None):
        marketId = self.safe_string(order, 'product_id')
        symbol = self.safe_symbol(marketId)
        if symbol is not None:
            market = self.market(symbol)

        id = self.safe_string(order, 'id')
        timestamp = self.parse8601(self.safe_string(order, 'created_at'))
        status = self.parse_order_status(self.safe_string(
            order, 'status'), self.safe_string(order, 'reason'))

        amount = self.safe_string(order, 'size')
        filled = self.safe_string(order, 'filled_size')
        remaining = Precise.string_sub(amount, filled)


        side = self.safe_string(order, 'side')
        type = self.safe_string(order, 'type')

        price = self.safe_string(order, 'price')
        timeInForce = self.safe_string(order, 'time_in_force')
        if timeInForce:
            timeInForce = timeInForce.upper()
        postOnly = self.safe_value(order, 'post_only')
        if postOnly:
            timeInForce = 'PO'

        executed_value = self.safe_string(order, 'executed_value', 0)
        average = Precise.string_div(executed_value, filled)

        return self.safe_order({
            'id': id,
            'clientOrderId': None,
            'timestamp': timestamp,
            'datetime': self.iso8601(timestamp),
            'lastTradeTimestamp': None,
            'status': status,
            'symbol': symbol,
            'type': type,
            'timeInForce': timeInForce,
            'side': side,
            'price': price,
            'average': average,
            'amount': amount,
            'filled': filled,
            'remaining': remaining,
            'cost': executed_value,
            'trades': None,
            'fee': None,
            'info': order,
        }, market)
    
    def create_order(self, symbol: str, type: OrderType, side: OrderSide, amount, price=None, params={}):
        """
        TODO: add stop order support
        """
        self.load_markets()
        market = self.market(symbol)

        request = {
            'product_id': market['id'],
            'side': side,  # "buy" or "sell"
            # 'price': 30000,  # send None for market orders
            'type': type,  # "limit", "market", "stop", "trailingStop", or "takeProfit"
            'size': float(self.amount_to_precision(symbol, amount)),
            # 'reduce_only': False,  # optional, default is False
            # "time_in_force": 'gtc', # optional, 'gtc', 'ioc', 'fok'
            # 'post_only': False,  # optional, default is False, limit orders only
            # 'stop': None # optional, "entry", "loss"
            # 'stop_price': None, #required if stop is not None
        }
        # Request:
        # {
        #     "product_id": 'btc_usd',
        #     "side": 'buy'/'sell',
        #     "size": integer,
        #     "type": 'limit'/'market',
        #     "price": None/float,
        #     "stop": 'entry'/'loss'/None,
        #     "stop_price": None/float,
        #     "time_in_force": 'gtc'/'ioc'/'fok',
        #     "post_only": bool,
        #     "reduce_only": bool
        #     "stp": "dc"/"cn"/"co"/"cb",
        #                                     #         "dc": decrease and cancel
        #                                     #         "cn": cancel new
        #                                     #         "co": cancel old
        #                                     #         "cb": cancel both
        # }
        # Return:
        # {
        #     "created_at": "2021-07-09T21:59:35.714065+00:00",
        #     "executed_value": 0,
        #     "filled_size": 0,
        #     "id": "f2f23286-e100-11eb-8808-e6aa351fe500",
        #     "post_only": false,
        #     "price": "30000",
        #     "product_id": "btc_usd",
        #     "reduce_only": false,
        #     "settled": true,
        #     "side": "buy",
        #     "size": 1,
        #     "status": "pending",
        #     "stp": "dc",
        #     "time_in_force": "gtc",
        #     "type": "limit"
        # }

        if type == 'limit':
            request['price'] = float(self.price_to_precision(symbol, price))
        elif type == 'market':
            request['price'] = None
        else:
            raise InvalidOrder(
                self.id + ' createOrder() does not support order type ' + type + ', only limit, market orders are supported')

        # stopPrice = self.safe_number_n(params, ['stopPrice', 'stop_price', 'triggerPrice'])
        # stopLossPrice = self.safe_number(params, 'stopLossPrice')
        # takeProfitPrice = self.safe_number(params, 'takeProfitPrice')
            
        timeInForce = self.safe_string(params, 'timeInForce')
        postOnly = True if (timeInForce == 'PO') else self.safe_value_2(params, 'postOnly', 'post_only', False)

        if timeInForce:
            if timeInForce not in ['GTC', 'IOC', 'FOK', 'PO']:
                raise InvalidOrder(
                    self.id + ' createOrder() does not support time in force ' + timeInForce + ', only GTC, IOC, FOK are supported')
            elif timeInForce in ['GTC', 'IOC', 'FOK']:
                request['time_in_force'] = timeInForce.lower()

        if postOnly:
            request['post_only'] = postOnly
        response = self.privatePostOrder(self.extend(request, params))
        
        return self.parse_order(response)

    def sign(self, path, api='public', method='GET', params={}, headers=None, body=None):
        query = '/api/' + self.implode_params(path, params)
        params = self.omit(params, self.extract_params(path))

        if method == 'GET':
            if params:
                query += '?' + self.urlencode(params)

        url = self.urls['api'] + query
        if api == 'private':
            self.check_required_credentials()

            nonce = str(self.nonce())
            payload = ''
            if method != 'GET':
                if params:
                    body = self.json(params)
                    payload = body

            auth = nonce + method + query + payload
            hash = self.hash(self.encode(
                "\x19Ethereum Signed Message:\n" + str(len(auth)) + auth), 'keccak')
            signature = self.ecdsa(
                hash[-64:], self.privateKey[-64:], algorithm="secp256k1")
            signature = '0x' + signature['r'] + \
                signature['s'] + hex(int(signature['v'] + 27))[2:]
            headers = {
                'ACCESS-SIGN': signature,
                'ACCESS-TIMESTAMP': nonce,
                'Content-Type': 'application/json',
            }
        return {'url': url, 'method': method, 'body': body, 'headers': headers}